const $=s=>document.querySelector(s);
async function post(path,payload){const r=await fetch(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)});const data=await r.json().catch(()=>({}));return {r,data};}
function message(el,text,good=false){el.textContent=text;el.classList.toggle('successText',good);}

const params=new URLSearchParams(location.search);
const verifyToken=params.get('verify');
const resetToken=params.get('reset');
if (verifyToken || resetToken) history.replaceState(null,'','/auth.html');

if (verifyToken || resetToken) {
  $('#standardAuth').hidden=true; $('#recovery').hidden=true; $('#tokenFlow').hidden=false;
  if (verifyToken) {
    $('#tokenEyebrow').textContent='EMAIL VERIFICATION'; $('#tokenTitle').textContent='Verifying your email…';
    const {r,data}=await post('/api/auth/verify-email',{token:verifyToken});
    if (r.ok) { $('#tokenTitle').textContent='Email verified'; message($('#tokenMessage'),'Your workspace is ready. Redirecting to Vendor Watch…',true); setTimeout(()=>location.href='/vendors.html',700); }
    else { $('#tokenTitle').textContent='This verification link is no longer valid'; message($('#tokenMessage'),'Request a new verification email from the sign-in page.'); $('#tokenStatus').innerHTML='<a href="/auth.html">Return to sign in</a>'; }
  } else {
    $('#tokenEyebrow').textContent='PASSWORD RESET'; $('#tokenTitle').textContent='Choose a new password'; $('#tokenMessage').textContent='This one-time link will be consumed when the password is changed.'; $('#resetForm').hidden=false;
  }
}

$('#register').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,status=$('#registerStatus'),fd=new FormData(form);message(status,'Creating workspace…');const {r,data}=await post('/api/auth/register',{email:fd.get('email'),password:fd.get('password')});if(!r.ok){message(status,data.message||data.error||'Request failed');return;}message(status,'Workspace created. Check your email for the verification link before signing in.',true);form.querySelector('button').disabled=true;};

$('#login').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,status=$('#loginStatus'),fd=new FormData(form);message(status,'Signing in…');const email=fd.get('email');const {r,data}=await post('/api/auth/login',{email,password:fd.get('password')});if(r.ok){location.href='/vendors.html';return;}if(r.status===403&&data.error==='email_verification_required'){message(status,'Email verification is required.');const resend=document.createElement('button');resend.type='button';resend.className='linkButton';resend.textContent='Resend verification email';resend.onclick=async()=>{resend.disabled=true;await post('/api/auth/resend-verification',{email});resend.textContent='Verification email requested';};status.append(document.createElement('br'),resend);return;}message(status,data.message||data.error||'Sign in failed');};

$('#forgotToggle').onclick=()=>{$('#recovery').hidden=false;$('#forgotToggle').hidden=true;};
$('#forgotForm').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.currentTarget),status=$('#forgotStatus');message(status,'Requesting reset…');const {r,data}=await post('/api/auth/request-password-reset',{email:fd.get('email')});message(status,r.ok?(data.message||'If that account exists, a reset email has been queued.'):(data.message||data.error||'Request failed'),r.ok);};

$('#resetForm').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.currentTarget),status=$('#tokenStatus');message(status,'Changing password…');const {r,data}=await post('/api/auth/reset-password',{token:resetToken,password:fd.get('password')});if(!r.ok){message(status,data.message||data.error||'Reset failed');return;}message(status,'Password changed. Previous sessions have been revoked. Redirecting…',true);setTimeout(()=>location.href='/vendors.html',700);};
