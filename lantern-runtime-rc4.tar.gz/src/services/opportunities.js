import { scoreOpportunity } from '../domain/scoring.js';
import { extractRequirements } from '../domain/requirements.js';

function mergeRequirements(existing = [], extracted = []) {
  const seen = new Set();
  const out = [];
  for (const item of [...existing, ...extracted]) {
    const key = String(item?.text || '').trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}


function mergeSyncedOpportunity(existing, incoming) {
  if (!existing) return incoming;
  return {
    ...existing,
    ...incoming,
    description: incoming.description || existing.description || '',
    requirements: mergeRequirements(existing.requirements || [], incoming.requirements || []),
    enrichedAt: existing.enrichedAt || incoming.enrichedAt || null,
    enrichment: existing.enrichment || incoming.enrichment || null
  };
}

export class OpportunityService {
  constructor({ store, provider, detailProvider = null }) {
    this.store = store;
    this.provider = provider;
    this.detailProvider = detailProvider;
  }
  async list() {
    const [profile, items, decisions] = await Promise.all([
      this.store.getProfile(),
      this.store.getOpportunities(),
      this.store.getDecisions ? this.store.getDecisions() : {}
    ]);
    return items
      .map(item => ({ ...item, decision: decisions[item.id] || { status:'new', note:'', updatedAt:null }, match: scoreOpportunity(profile, item) }))
      .sort((a, b) => b.match.score - a.match.score);
  }
  async get(id) {
    const items = await this.list();
    return items.find(x => x.id === id) || null;
  }
  async sync() {
    const [incoming, existing] = await Promise.all([this.provider(), this.store.getOpportunities()]);
    const byId = new Map(existing.map(item => [String(item.id), item]));
    const items = incoming.map(item => mergeSyncedOpportunity(byId.get(String(item.id)), item));
    await this.store.saveOpportunities(items);
    return { count: items.length, syncedAt: new Date().toISOString() };
  }
  async enrich(id) {
    const current = await this.store.findOpportunity(id);
    if (!current) return null;
    if (!current.descriptionUrl) {
      const extracted = current.description ? extractRequirements(current.description, { source:`SAM.gov description · ${current.id}` }) : [];
      const requirements = mergeRequirements(current.requirements || [], extracted);
      const saved = { ...current, requirements, enrichedAt:new Date().toISOString(), enrichment:{ source:'embedded-description', cache:'n/a' } };
      await this.store.replaceOpportunity(saved);
      return this.get(id);
    }
    if (!this.detailProvider) throw new Error('opportunity enrichment is not configured');
    const detail = await this.detailProvider.get({ id:current.id, descriptionUrl:current.descriptionUrl });
    const requirements = mergeRequirements(current.requirements || [], extractRequirements(detail.description, { source:`SAM.gov description · ${current.id}` }));
    const saved = {
      ...current,
      description: detail.description,
      requirements,
      enrichedAt: new Date().toISOString(),
      enrichment: { source:'sam.gov', cache:detail.cache, fetchedAt:detail.fetchedAt, stale:detail.cache === 'stale-fallback' }
    };
    await this.store.replaceOpportunity(saved);
    return this.get(id);
  }
}
