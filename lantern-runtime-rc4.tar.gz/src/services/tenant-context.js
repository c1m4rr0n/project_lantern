import { TenantJsonStore } from '../storage/tenant-json-store.js';
import { OpportunityService } from './opportunities.js';

export function createTenantContext({ store = null, tenantRoot, tenantId, provider, detailProvider = null, seedProfile, seedOpportunities }) {
  const tenantStore = store || new TenantJsonStore({ root: tenantRoot, tenantId, seedProfile, seedOpportunities });
  return { store:tenantStore, service: new OpportunityService({ store:tenantStore, provider, detailProvider }) };
}
