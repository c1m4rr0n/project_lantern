import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

const SAFE_TENANT = /^[a-zA-Z0-9-]{8,80}$/;

async function readJson(path, fallback) {
  try { return JSON.parse(await readFile(path, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return structuredClone(fallback); throw error; }
}

async function atomicJson(path, value) {
  await mkdir(resolve(path, '..'), { recursive: true });
  const tmp = `${path}.${process.pid}.tmp`;
  await writeFile(tmp, JSON.stringify(value, null, 2));
  await rename(tmp, path);
}

export class TenantJsonStore {
  constructor({ root, tenantId, seedProfile = null, seedOpportunities = [] }) {
    if (!SAFE_TENANT.test(String(tenantId))) throw new Error('invalid tenant id');
    this.root = resolve(root);
    this.tenantId = String(tenantId);
    this.dir = join(this.root, this.tenantId);
    this.profilePath = join(this.dir, 'profile.json');
    this.opportunitiesPath = join(this.dir, 'opportunities.json');
    this.decisionsPath = join(this.dir, 'decisions.json');
    this.seedProfile = seedProfile;
    this.seedOpportunities = seedOpportunities;
  }
  async getProfile() { return readJson(this.profilePath, this.seedProfile || { name:'', naics:[], capabilities:[], setAsides:[], regions:[], negativeKeywords:[] }); }
  async saveProfile(profile) { await atomicJson(this.profilePath, profile); return profile; }
  async getOpportunities() { return readJson(this.opportunitiesPath, this.seedOpportunities); }
  async saveOpportunities(items) { await atomicJson(this.opportunitiesPath, items); return items; }
  async findOpportunity(id) { return (await this.getOpportunities()).find(x => String(x.id) === String(id)) || null; }
  async replaceOpportunity(item) {
    const items = await this.getOpportunities();
    const index = items.findIndex(x => String(x.id) === String(item.id));
    if (index < 0) throw new Error('opportunity not found');
    items[index] = item;
    await this.saveOpportunities(items);
    return item;
  }
  async getDecisions() { return readJson(this.decisionsPath, {}); }
  async saveDecision(opportunityId, decision) { const all=await this.getDecisions(); all[String(opportunityId)] = decision; await atomicJson(this.decisionsPath, all); return decision; }
}
