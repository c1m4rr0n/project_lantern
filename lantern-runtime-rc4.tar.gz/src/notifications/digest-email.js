function esc(value='') {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function list(items, render, empty='None today') {
  if (!items?.length) return `<p style="color:#667085">${esc(empty)}</p>`;
  return `<ul>${items.map(render).join('')}</ul>`;
}

export function renderDigestEmail(digest) {
  const company=digest.company || 'your company';
  const subject=`Lantern daily brief — ${digest.strongCount} strong match${digest.strongCount===1?'':'es'}`;
  const top=list(digest.topMatches, item=>`<li><strong>${esc(item.title)}</strong> — ${esc(item.score)}/100${item.deadline?` · due ${esc(item.deadline)}`:''}<br><span style="color:#475467">${esc((item.reasons||[]).join(' · '))}</span></li>`,'No strong matches today.');
  const deadlines=list(digest.upcomingDeadlines, item=>`<li><strong>${esc(item.title)}</strong> — ${esc(item.daysRemaining)} day${item.daysRemaining===1?'':'s'} remaining</li>`,'No deadlines within 14 days.');
  const html=`<!doctype html><html><body style="font-family:Arial,sans-serif;color:#101828;line-height:1.5"><div style="max-width:680px;margin:auto;padding:24px"><p style="font-size:12px;font-weight:700;letter-spacing:.08em;color:#667085">PROJECT LANTERN · DAILY BRIEF</p><h1 style="font-size:28px;margin-bottom:4px">${esc(company)}</h1><p style="color:#667085;margin-top:0">${esc(digest.scanned)} opportunities scanned · ${esc(digest.strongCount)} strong · ${esc(digest.reviewCount)} review · ${esc(digest.pursueCount)} pursuing</p><h2>Best matches</h2>${top}<h2>Deadlines</h2>${deadlines}<p style="font-size:12px;color:#98a2b3;margin-top:28px">Lantern ranks public opportunities using your saved profile. Verify solicitation requirements in the official source before acting.</p></div></body></html>`;
  const text=[
    `PROJECT LANTERN — DAILY BRIEF`,
    company,
    `${digest.scanned} scanned · ${digest.strongCount} strong · ${digest.reviewCount} review · ${digest.pursueCount} pursuing`,
    '',
    'BEST MATCHES',
    ...(digest.topMatches?.length?digest.topMatches.map(x=>`- ${x.title} — ${x.score}/100${x.deadline?` — due ${x.deadline}`:''}`):['- No strong matches today.']),
    '',
    'DEADLINES',
    ...(digest.upcomingDeadlines?.length?digest.upcomingDeadlines.map(x=>`- ${x.title} — ${x.daysRemaining} day(s) remaining`):['- No deadlines within 14 days.']),
    '',
    'Verify solicitation requirements in the official source before acting.'
  ].join('\n');
  return {subject,html,text};
}
