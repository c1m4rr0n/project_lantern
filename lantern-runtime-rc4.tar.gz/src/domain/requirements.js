const KEYWORDS = /\b(shall|must|required|requirement|submit|provide|include|due|deadline|certif(?:y|ication)|registration)\b/i;
const MANDATORY = /\b(shall|must|required|is required|are required)\b/i;

function clean(line) {
  return String(line || '').replace(/^[-*•\s\d.)]+/, '').replace(/\s+/g, ' ').trim();
}

export function extractRequirements(text, { source = 'SAM.gov opportunity description', max = 30 } = {}) {
  const raw = String(text || '').replace(/\r/g, '');
  const chunks = raw.split(/\n+|(?<=[.!?])\s+(?=[A-Z0-9])/g).map(clean).filter(Boolean);
  const seen = new Set();
  const out = [];
  for (const chunk of chunks) {
    if (chunk.length < 12 || chunk.length > 700 || !KEYWORDS.test(chunk)) continue;
    const fingerprint = chunk.toLowerCase();
    if (seen.has(fingerprint)) continue;
    seen.add(fingerprint);
    out.push({
      text: chunk,
      mandatory: MANDATORY.test(chunk),
      source,
      status: 'unverified'
    });
    if (out.length >= max) break;
  }
  return out;
}
