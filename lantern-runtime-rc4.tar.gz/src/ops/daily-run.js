import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { buildDigest } from '../services/digest.js';
import { OpportunityService } from '../services/opportunities.js';

function dayKey(now) { return now.toISOString().slice(0,10); }
function configured(profile) {
  return Boolean(profile?.name || profile?.naics?.length || profile?.capabilities?.length || profile?.setAsides?.length || profile?.regions?.length);
}
async function writeOnce(path, value) {
  try { await writeFile(path, JSON.stringify(value, null, 2), { flag:'wx', mode:0o600 }); return true; }
  catch (error) { if (error.code === 'EEXIST') return false; throw error; }
}

export async function runDaily({ accountStore, tenantStoreFor, provider, seedOpportunities = [], outboxRoot, now = new Date() }) {
  const startedAt = new Date().toISOString();
  const users = await accountStore.listUsers();
  const results = [];
  const eligible=[];

  for (const user of users) {
    if (!user.emailVerifiedAt) { results.push({tenantId:user.tenantId,status:'skipped-unverified'}); continue; }
    const store = tenantStoreFor(user.tenantId, { seedOpportunities });
    const profile = await store.getProfile();
    if (!configured(profile)) { results.push({tenantId:user.tenantId,status:'skipped-unconfigured'}); continue; }
    eligible.push({user,store,profile});
  }

  const sharedItems = eligible.length ? await provider() : [];
  await mkdir(outboxRoot, { recursive:true });

  for (const {user,store,profile} of eligible) {
    const service = new OpportunityService({ store, provider:async()=>sharedItems });
    await service.sync();
    const items = await service.list();
    const digest = buildDigest(profile, items, now);
    const idempotencyKey = `daily:${dayKey(now)}:${user.tenantId}`;
    const message = {
      idempotencyKey,
      channel:'email',
      template:'daily-digest',
      to:user.email,
      createdAt:new Date().toISOString(),
      payload:digest
    };
    const path = join(outboxRoot, `${dayKey(now)}-${user.tenantId}.json`);
    const created = await writeOnce(path, message);
    results.push({ tenantId:user.tenantId, status:created ? 'queued' : 'already-queued', strongCount:digest.strongCount, deadlineCount:digest.deadlineCount });
  }

  return {
    ok:true,
    startedAt,
    finishedAt:new Date().toISOString(),
    date:dayKey(now),
    tenants:users.length,
    eligibleTenants:eligible.length,
    opportunitiesFetched:sharedItems.length,
    queued:results.filter(x=>x.status==='queued').length,
    alreadyQueued:results.filter(x=>x.status==='already-queued').length,
    skipped:results.filter(x=>x.status.startsWith('skipped')).length,
    results
  };
}
