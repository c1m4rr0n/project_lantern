import { mkdir, readdir, readFile, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { renderDigestEmail } from './digest-email.js';
import { renderPasswordResetEmail, renderVerificationEmail } from './auth-email.js';

function renderMessage(message) {
  if (message.channel !== 'email' || !message.to || !message.idempotencyKey) throw new Error('invalid outbox message');
  if (message.template === 'daily-digest') return { ...renderDigestEmail(message.payload || {}), sensitive:false };
  if (message.template === 'verify-email') return { ...renderVerificationEmail(message.payload || {}), sensitive:true };
  if (message.template === 'password-reset') return { ...renderPasswordResetEmail(message.payload || {}), sensitive:true };
  throw new Error('invalid outbox message');
}

export async function deliverOutbox({ outboxRoot, sender, limit=100, now=new Date() }) {
  const sentDir=join(outboxRoot,'sent');
  const failedDir=join(outboxRoot,'failed');
  await Promise.all([mkdir(sentDir,{recursive:true}),mkdir(failedDir,{recursive:true})]);
  const files=(await readdir(outboxRoot)).filter(x=>x.endsWith('.json')).sort().slice(0,Math.max(1,Number(limit)||100));
  const results=[];
  for (const file of files) {
    const path=join(outboxRoot,file);
    let message;
    try {
      message=JSON.parse(await readFile(path,'utf8'));
      const rendered=renderMessage(message);
      const receipt=await sender({...message,subject:rendered.subject,html:rendered.html,text:rendered.text});
      const completed={...message,deliveredAt:now.toISOString(),receipt};
      if (rendered.sensitive) completed.payload={redacted:true};
      await writeFile(path,JSON.stringify(completed,null,2),{mode:0o600});
      await rename(path,join(sentDir,file));
      results.push({file,status:'sent',provider:receipt.provider,id:receipt.id});
    } catch (error) {
      const failure={file,status:'failed',error:error.message};
      // Invalid payloads are quarantined. Provider/network failures stay in place for retry.
      if (error.message === 'invalid outbox message') await rename(path,join(failedDir,file));
      results.push(failure);
    }
  }
  return {ok:results.every(x=>x.status==='sent'),processed:results.length,sent:results.filter(x=>x.status==='sent').length,failed:results.filter(x=>x.status==='failed').length,results};
}
