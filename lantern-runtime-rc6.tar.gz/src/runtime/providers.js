import { join } from 'node:path';
import { fetchMockOpportunities } from '../providers/mock.js';
import { fetchSamOpportunities } from '../providers/sam.js';
import { SamDetailCache } from '../providers/sam-detail.js';
import { SamWatchCache } from '../providers/sam-watch.js';
import { makeCachedProvider } from '../providers/cached-provider.js';
import { fetchUsaSpendingContext } from '../providers/usaspending.js';
import { fetchMockMarketContext } from '../providers/mock-market.js';

export function createProviders({ env = process.env, dataRoot, fetchImpl = fetch }) {
  const providerName = env.DATA_PROVIDER || (env.SAM_API_KEY ? 'sam' : 'mock');
  const upstreamProvider = providerName === 'sam'
    ? () => fetchSamOpportunities({ apiKey:env.SAM_API_KEY, lookbackDays:env.SAM_LOOKBACK_DAYS || 2, fetchImpl })
    : fetchMockOpportunities;
  const provider = makeCachedProvider({
    provider:upstreamProvider,
    path:join(dataRoot, 'cache/opportunities.json'),
    ttlMs:Number(env.OPPORTUNITY_CACHE_TTL_MS || 900000),
    maxStaleMs:Number(env.OPPORTUNITY_MAX_STALE_MS || 86400000)
  });
  const detailProvider = providerName === 'sam' && env.SAM_API_KEY
    ? new SamDetailCache({
        root:join(dataRoot, 'cache/sam-details'),
        apiKey:env.SAM_API_KEY,
        ttlMs:Number(env.SAM_DETAIL_CACHE_TTL_MS || 21600000),
        maxStaleMs:Number(env.SAM_DETAIL_MAX_STALE_MS || 604800000),
        fetchImpl
      })
    : null;
  const watchProvider = providerName === 'sam' && env.SAM_API_KEY
    ? new SamWatchCache({
        root:join(dataRoot, 'cache/sam-watch'),
        apiKey:env.SAM_API_KEY,
        ttlMs:Number(env.SAM_WATCH_CACHE_TTL_MS || 1800000),
        maxStaleMs:Number(env.SAM_WATCH_MAX_STALE_MS || 604800000),
        fetchImpl
      })
    : null;
  const marketProviderName = env.MARKET_PROVIDER || 'mock';
  const marketProvider = marketProviderName === 'usaspending' ? fetchUsaSpendingContext : fetchMockMarketContext;
  return { providerName, provider, detailProvider, watchProvider, marketProviderName, marketProvider };
}
